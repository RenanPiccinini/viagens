# Internacionais – Exclusiva

Captured from: https://exclusivaviagens.com.br/internacionais/
At: 2026-09-27T23:35:22.689Z

## Como usar no Lovable
1. Abra o Lovable e crie/abra um projeto.
2. Faça upload deste `.zip` — os arquivos já estão na raiz, prontos para importar.
3. Peça ao Lovable para converter em React ou editar as seções.

## Rodar localmente
```bash
npm install
npm run dev
```

## Conteúdo
- `index.html` — HTML renderizado com paths locais
- `styles.css` — stylesheets mescladas
- `assets/images/`, `assets/fonts/`
- `screenshots/` — 6 screenshots seção por seção
- `clone-data.json` — metadata da captura
- `package.json` + `vite.config.js` — scaffold para Lovable/Vite
